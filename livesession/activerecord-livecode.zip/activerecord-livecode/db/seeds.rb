require 'faker'

50.times do
  job = Job.new(
   name: Faker::Name.title,
   company: Faker::Company.name,
   location: Faker::Address.city,
   likes: (0..100).to_a.sample,
   remote_work: true
    )
  job.save
end
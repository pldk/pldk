

class Migratecode < ActiveRecord::Migration
  def change
    create_table :jobs do |t|
      t.string :name
      t.string :company
      t.string :location
      t.timestamp :created_at
      t.timestamp :updated_at
    end
  end
end
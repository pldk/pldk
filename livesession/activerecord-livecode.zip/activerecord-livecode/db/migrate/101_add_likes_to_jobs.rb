class AddLikesToJobs < ActiveRecord::Migration
  def change
    add_column :jobs, :likes, :integer
    add_column :jobs, :remote_work, :boolean, default: false
  end
end
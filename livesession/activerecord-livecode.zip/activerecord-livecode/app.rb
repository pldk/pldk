require_relative 'config/application'
require_relative 'app/models/job'

good_job = Job.new(name: "Software Developer")
good_job.save
p Job.all
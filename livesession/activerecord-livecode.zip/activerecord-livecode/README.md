# Migration

## First attempt
* Create a jobs table
* Jobs have name, company, location (all strings)
* Open in sqlite

## Update
* Jobs have a number of likes
* Jobs can be opened to remote workers

# Model
* Create the job class
* Show what happens when looking for 

# Seed
* Create some basic jobs
